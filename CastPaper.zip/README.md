![Cast Paper](https://github.com/Uno-Takashi/CastPaper/blob/master/logo/logo.png?raw=true "Cast Paper icon")

Cast Paperは英語論文などに含まれる改行の削除を行うためのクローム拡張機能です。
ユーザーは通常のコピーと同様に右クリック内のメニューから改行を消したコピーが可能になります

論文をはじめとした、一般的なpdfをコピーした場合、各行の終端に改行が入ってしまい、コピーした内容にDeepLやgoogle翻訳を適応したい場合、改行を削除する処理を行わなくてはなりませんでした。
それを気軽に行うことが可能なウェブサービスは存在していましたが、本プロジェクトではさらなる効率化のためにGoogle Chromeの拡張機能として組み込むことでより容易にコピー＆ペーストを可能にします。

