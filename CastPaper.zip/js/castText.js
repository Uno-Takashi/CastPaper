function castText(string){
    var result = string;
	return result;
  }